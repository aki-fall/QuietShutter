package app.quietshutter;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

/** 삼성 CSC 강제 셔터음 설정(0 = 무음, 1 = 강제 소리)을 읽고 씁니다. */
final class Mute {
    static final String KEY = "csc_pref_camera_forced_shuttersound_key";
    private static final String PREFS = "quietshutter";
    private static final String WANT = "want_muted";

    /** 마지막 쓰기 시도의 결과 설명(진단용). */
    static String lastError = "";

    private Mute() {}

    static boolean canWrite(Context c) {
        return Settings.System.canWrite(c);
    }

    /** 현재 시스템 값이 무음(0)인지. */
    static boolean isMuted(Context c) {
        try {
            return Settings.System.getInt(c.getContentResolver(), KEY, 1) == 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** 사용자가 마지막으로 원한 상태(부팅/업데이트 후 재적용용). */
    static boolean wantMuted(Context c) {
        return prefs(c).getBoolean(WANT, false);
    }

    /**
     * 값을 쓰고, 실제로 반영됐는지 다시 읽어서 확인합니다.
     * @return 반영 성공 여부
     */
    static boolean setMuted(Context c, boolean mute) {
        prefs(c).edit().putBoolean(WANT, mute).apply();
        try {
            Settings.System.putInt(c.getContentResolver(), KEY, mute ? 0 : 1);
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName() + ": " + e.getMessage();
            return false;
        }
        boolean ok = isMuted(c) == mute;
        lastError = ok ? "" : "쓰기 호출은 예외 없이 끝났지만 다시 읽은 값이 " + raw(c) + " 입니다";
        return ok;
    }

    static String raw(Context c) {
        try {
            return String.valueOf(Settings.System.getInt(c.getContentResolver(), KEY));
        } catch (Exception e) {
            return "없음(" + e.getClass().getSimpleName() + ")";
        }
    }

    static boolean hasSecure(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
