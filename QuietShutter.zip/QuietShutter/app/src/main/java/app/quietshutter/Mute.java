package app.quietshutter;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.provider.Settings;

/** 삼성 강제 셔터음 설정(0 = 무음, 1 = 강제 소리). S26에서는 Secure 테이블에 있습니다. */
final class Mute {
    static final String KEY = "csc_pref_camera_forced_shuttersound_key";
    static final String GRANT_CMD =
            "adb shell pm grant app.quietshutter android.permission.WRITE_SECURE_SETTINGS";
    private static final String PREFS = "quietshutter";
    private static final String WANT = "want_muted";
    private static final int NONE = Integer.MIN_VALUE;

    /** 마지막 쓰기 시도의 결과 설명(진단용). */
    static String lastError = "";

    private Mute() {}

    static boolean hasSecure(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Secure 우선, 없으면 System에서 값을 읽습니다. 없으면 NONE. */
    private static int read(Context c) {
        int v = Settings.Secure.getInt(c.getContentResolver(), KEY, NONE);
        if (v == NONE) v = Settings.System.getInt(c.getContentResolver(), KEY, NONE);
        return v;
    }

    static String raw(Context c) {
        try {
            int v = read(c);
            return v == NONE ? "없음" : String.valueOf(v);
        } catch (Exception e) {
            return "읽기오류(" + e.getClass().getSimpleName() + ")";
        }
    }

    static boolean isMuted(Context c) {
        try {
            return read(c) == 0;
        } catch (Exception e) {
            return false;
        }
    }

    /** 사용자가 마지막으로 원한 상태(부팅 후 재적용용). */
    static boolean wantMuted(Context c) {
        return prefs(c).getBoolean(WANT, false);
    }

    /** 값을 쓰고 다시 읽어서 실제 반영 여부를 확인합니다. */
    static boolean setMuted(Context c, boolean mute) {
        prefs(c).edit().putBoolean(WANT, mute).apply();
        try {
            Settings.Secure.putInt(c.getContentResolver(), KEY, mute ? 0 : 1);
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName() + ": " + e.getMessage();
            return false;
        }
        boolean ok = isMuted(c) == mute;
        lastError = ok ? "" : "쓰기는 예외 없이 끝났지만 다시 읽은 값이 " + raw(c) + " 입니다";
        return ok;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
