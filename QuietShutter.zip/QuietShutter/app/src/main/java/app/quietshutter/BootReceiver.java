package app.quietshutter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 재부팅/앱 업데이트 후, 사용자가 무음을 켜 둔 상태였다면 다시 적용합니다. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        if (Mute.wantMuted(c) && Mute.hasSecure(c) && !Mute.isMuted(c)) {
            Mute.setMuted(c, true);
        }
    }
}
