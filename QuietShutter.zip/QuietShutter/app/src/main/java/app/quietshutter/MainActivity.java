package app.quietshutter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Switch toggle;
    private TextView status;
    private boolean updating;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(pad, pad, pad, pad);

        toggle = new Switch(this);
        toggle.setText("카메라 셔터음 끄기");
        toggle.setTextSize(22);
        toggle.setPadding(pad, pad, pad, pad);

        status = new TextView(this);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);

        root.addView(toggle);
        root.addView(status);
        setContentView(root);

        toggle.setOnCheckedChangeListener((v, checked) -> {
            if (updating) return;
            if (!Mute.canWrite(this)) {
                requestWritePermission();
                refresh();
                return;
            }
            Mute.setMuted(this, checked);
            refresh();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void requestWritePermission() {
        Intent i = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private void refresh() {
        updating = true;
        boolean muted = Mute.isMuted(this);
        toggle.setChecked(muted);
        updating = false;

        if (!Mute.canWrite(this)) {
            status.setText("시스템 설정 수정 권한이 필요합니다.\n스위치를 누르면 권한 화면이 열립니다.");
        } else if (Mute.wantMuted(this) && !muted) {
            status.setText("무음을 요청했지만 시스템이 값을 되돌렸거나 쓰기를 거부했습니다.");
        } else {
            status.setText(muted ? "현재: 무음" : "현재: 소리 켜짐");
        }
    }
}
