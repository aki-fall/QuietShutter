package app.quietshutter;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Switch toggle;
    private TextView status;
    private boolean updating;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(pad, pad, pad, pad);

        toggle = new Switch(this);
        toggle.setText("카메라 셔터음 끄기");
        toggle.setTextSize(22);
        toggle.setPadding(pad, pad, pad, pad);

        status = new TextView(this);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setTextIsSelectable(true);

        root.addView(toggle);
        root.addView(status);
        setContentView(root);

        toggle.setOnCheckedChangeListener((v, checked) -> {
            if (updating) return;
            if (Mute.hasSecure(this)) {
                Mute.setMuted(this, checked);
            }
            refresh();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        updating = true;
        boolean muted = Mute.isMuted(this);
        toggle.setChecked(muted);
        updating = false;

        if (!Mute.hasSecure(this)) {
            status.setText("보안 설정 쓰기 권한이 필요합니다.\nPC에서 아래 명령을 한 번만 실행하세요:\n\n"
                    + Mute.GRANT_CMD);
        } else if (Mute.wantMuted(this) && !muted) {
            status.setText("무음을 요청했지만 적용되지 않았습니다.\n\n" + Mute.lastError);
        } else {
            status.setText(muted ? "현재: 무음" : "현재: 소리 켜짐");
        }
        status.append("\n\n[진단] 값=" + Mute.raw(this)
                + " / 보안설정권한=" + Mute.hasSecure(this)
                + "\nSDK=" + android.os.Build.VERSION.SDK_INT
                + " / " + android.os.Build.MODEL);
    }
}
